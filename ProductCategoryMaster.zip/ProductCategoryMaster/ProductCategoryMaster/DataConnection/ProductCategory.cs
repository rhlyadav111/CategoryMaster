﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using ProductCategoryMaster.Models;

namespace ProductCategoryMaster.DataConnection
{
    public class ProductCategory : DbContext
    {
        public ProductCategory() : base("ProductCategory")
        {

        }
        public DbSet<Product> Products { get; set; }
        public DbSet<Category> Categories { get; set; }
    }
}