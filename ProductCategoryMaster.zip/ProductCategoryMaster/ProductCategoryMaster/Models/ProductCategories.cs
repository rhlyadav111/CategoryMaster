﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProductCategoryMaster.Models
{
    public class ProductCategories
    {
        public Product Products { get; set; }
        public Category Categories { get; set; }
    }
}