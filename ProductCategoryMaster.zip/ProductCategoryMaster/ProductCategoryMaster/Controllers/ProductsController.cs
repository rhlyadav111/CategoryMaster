﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using ProductCategoryMaster.DataConnection;
using ProductCategoryMaster.Models;

namespace ProductCategoryMaster.Controllers
{
    public class ProductsController : Controller
    {
        private ProductCategory db = new ProductCategory();

        // GET: Products
        public ActionResult Index(int currentPage)
        {
            int maxRows = 10;
            ProductModel productModel = new ProductModel();

            productModel.Products = (from product in db.Products
                                     select product)
                        .OrderBy(product => product.ProductId)
                        .Skip((currentPage - 1) * maxRows)
                        .Take(maxRows).ToList();
            double pageCount = (double)((decimal)db.Products.Count() / Convert.ToDecimal(maxRows));
            productModel.PageCount = (int)Math.Ceiling(pageCount);

            productModel.CurrentPageIndex = currentPage;
            ViewBag.Products = db.Products.AsEnumerable().ToList();
            return View(productModel);
        }

        // GET: Products/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Product product = db.Products.Find(id);
            if (product == null)
            {
                return HttpNotFound();
            }
            return View(product);
        }

        // GET: Products/Create
        public ActionResult Create()
        {
            ViewBag.CategoryList = db.Categories.Select(i => new SelectListItem
            {
                Text = i.CategoryName,
                Value = i.CategoryName
            }).AsEnumerable();
            return View();
        }

        // POST: Products/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ProductId,ProductName,CategoryName")] Product product)
        {
            if (ModelState.IsValid)
            {
                //var Products = new Product
                //{
                //    ProductId = product.ProductId,
                //    ProductName = product.ProductName,
                //    Category = db.Categories.Where(m => product.Category.CategoryId.Any(i => i.CategoryId == m.CategoryId))
                //};
                db.Products.Add(product);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(product);
        }

        // GET: Products/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Product product = db.Products.Find(id);
            int CategoryId = db.Products.Where(x => x.ProductId == id).Select(x => x.Category.CategoryId).FirstOrDefault();
            product.Category = db.Categories.Find(CategoryId);
            ViewBag.CategoryList = db.Categories.Select(i => new SelectListItem { 
                Text = i.CategoryName,
                Value = i.CategoryName
            }).AsEnumerable();
            ViewData["Category"] = product.Category.CategoryName;
            if (product == null)
            {
                return HttpNotFound();
            }
            return View(product);
        }

        // POST: Products/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ProductId,ProductName,Category")] Product product)
        {
            if (ModelState.IsValid)
            {
                db.Entry(product).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(product);
        }

        // GET: Products/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Product product = db.Products.Find(id);
            if (product == null)
            {
                return HttpNotFound();
            }
            return View(product);
        }

        // POST: Products/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Product product = db.Products.Find(id);
            db.Products.Remove(product);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
